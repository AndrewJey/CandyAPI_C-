﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CandyApi.Entity
{
    public class UsuarioMovimientos
    {
        public int usuario { set; get; }

        public int movimiento1 { set; get; }

        public int movimiento2 { set; get; }
    }
}