﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CandyApi.Entity
{
    public class Usuario
    {
        public int id { set; get; }

        public string username { set; get; }
    }
}